-- Teams management module for GVH mod
-- Лимиты команд 1v23, безопасное назначение игроков, переводы между командами и наблюдателями

Teams = {}

-- Инициализация лимитов команд
function Teams.SetupLimits()
  Util.Log("INFO", "Setting up team limits...")
  
  -- Проверяем, что конфиг загружен
  if not GVH or not GVH.SOLO_SLOTS or not GVH.HORDE_SLOTS then
    Util.Log("ERROR", "Config not loaded! Cannot set team limits.")
    return false
  end
  
  -- Проверяем, что GameRules готов
  if not GameRules or not GameRules.SetCustomGameTeamMaxPlayers then
    Util.Log("WARN", "GameRules not ready, deferring team limits setup...")
    -- Отложим инициализацию на потом
    if GameRules and GameRules:GetGameModeEntity() then
      GameRules:GetGameModeEntity():SetThink(Teams.SetupLimits, "setup_limits", 1.0)
    end
    return false
  end
  
  -- Устанавливаем лимиты команд
  local success = true
  success = success and Util.SetTeamMaxPlayers(GVH.TEAM_SOLO, GVH.SOLO_SLOTS)
  success = success and Util.SetTeamMaxPlayers(GVH.TEAM_HORDE, GVH.HORDE_SLOTS)
  success = success and Util.SetTeamMaxPlayers(GVH.TEAMS.SPECTATOR, GVH.MAX_SPECTATORS)
  
  if success then
    Util.Log("INFO", "Team limits set: Solo=%d, Horde=%d, Spectators=%d", 
             GVH.SOLO_SLOTS, GVH.HORDE_SLOTS, GVH.MAX_SPECTATORS)
  else
    Util.Log("ERROR", "Failed to set some team limits")
  end
  
  return success
end

-- Безопасное назначение игрока в команду с учетом лимитов
function Teams.SafeAssign(playerID)
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "SafeAssign: invalid playerID %s", tostring(playerID))
    return false
  end
  
  local currentTeam = Util.GetPlayerTeam(playerID)
  Util.Log("DEBUG", "SafeAssign: player %d currently in team %s", playerID, tostring(currentTeam))
  
  -- Если игрок уже в команде (не NOTEAM), не трогаем его
  if currentTeam and currentTeam ~= GVH.TEAMS.NOTEAM then
    Util.Log("DEBUG", "Player %d already assigned to team %d", playerID, currentTeam)
    return true
  end
  
  -- Пытаемся назначить в Solo команду
  if Util.HasTeamSlots(GVH.TEAM_SOLO, 1) then
    Util.Log("INFO", "Assigning player %d to Solo team", playerID)
    return Util.AssignPlayerToTeam(playerID, GVH.TEAM_SOLO)
  end
  
  -- Пытаемся назначить в Horde команду
  if Util.HasTeamSlots(GVH.TEAM_HORDE, 1) then
    Util.Log("INFO", "Assigning player %d to Horde team", playerID)
    return Util.AssignPlayerToTeam(playerID, GVH.TEAM_HORDE)
  end
  
  -- Назначаем в наблюдатели
  Util.Log("INFO", "No team slots available, assigning player %d to spectators", playerID)
  return Teams.MoveToSpectators(playerID)
end

-- Перевод игрока в наблюдатели
function Teams.MoveToSpectators(playerID, reason)
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "MoveToSpectators: invalid playerID %s", tostring(playerID))
    return false
  end
  
  reason = reason or "manual"
  Util.Log("INFO", "Moving player %d to spectators (reason: %s)", playerID, reason)
  
  -- Убеждаемся, что есть место в наблюдателях
  if not Util.EnsureSpectatorSlots(1) then
    Util.Log("ERROR", "Cannot ensure spectator slots for player %d", playerID)
    return false
  end
  
  -- Переводим игрока
  local success = Util.AssignPlayerToTeam(playerID, GVH.TEAMS.SPECTATOR)
  
  if success then
    -- Дополнительная очистка при переводе из-за смерти
    if reason == "death" then
      Teams.CleanupDeadPlayer(playerID)
    end
    
    Util.Log("INFO", "Player %d moved to spectators successfully", playerID)
  else
    Util.Log("ERROR", "Failed to move player %d to spectators", playerID)
  end
  
  return success
end

-- Очистка мертвого игрока
function Teams.CleanupDeadPlayer(playerID)
  if not Util.IsValidPlayerID(playerID) then
    return
  end
  
  local hero = Util.GetPlayerHero(playerID)
  if hero then
    Util.Log("DEBUG", "Cleaning up dead player %d hero", playerID)
    
    -- Устанавливаем очень долгое время возрождения
    Util.SetRespawnTime(hero, 99999)
    
    -- Удаляем героя
    Util.RemoveUnit(hero)
  end
  
  -- Помечаем игрока как исключенного
  if not _G.GVH_EliminatedPlayers then
    _G.GVH_EliminatedPlayers = {}
  end
  _G.GVH_EliminatedPlayers[playerID] = GameRules:GetGameTime()
end

-- Возврат игрока из наблюдателей в команду
function Teams.ReturnFromSpectators(playerID, targetTeam)
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "ReturnFromSpectators: invalid playerID %s", tostring(playerID))
    return false
  end
  
  if not GVH.ALLOW_SPECTATOR_RETURN then
    Util.Log("WARN", "Spectator return is disabled in config")
    return false
  end
  
  local currentTeam = Util.GetPlayerTeam(playerID)
  if currentTeam ~= GVH.TEAMS.SPECTATOR then
    Util.Log("WARN", "Player %d is not in spectators (team: %s)", playerID, tostring(currentTeam))
    return false
  end
  
  -- Проверяем, не исключен ли игрок
  if _G.GVH_EliminatedPlayers and _G.GVH_EliminatedPlayers[playerID] then
    local eliminatedTime = _G.GVH_EliminatedPlayers[playerID]
    local currentTime = GameRules:GetGameTime()
    local timeSinceElimination = currentTime - eliminatedTime
    
    if timeSinceElimination > GVH.RETURN_WINDOW_SECONDS then
      Util.Log("WARN", "Player %d return window expired (%d seconds ago)", playerID, timeSinceElimination)
      return false
    end
  end
  
  -- Определяем целевую команду
  if not targetTeam then
    -- Автоматический выбор команды
    if Util.HasTeamSlots(GVH.TEAM_SOLO, 1) then
      targetTeam = GVH.TEAM_SOLO
    elseif Util.HasTeamSlots(GVH.TEAM_HORDE, 1) then
      targetTeam = GVH.TEAM_HORDE
    else
      Util.Log("WARN", "No team slots available for player %d return", playerID)
      return false
    end
  else
    -- Проверяем доступность указанной команды
    if not Util.HasTeamSlots(targetTeam, 1) then
      Util.Log("WARN", "No slots in target team %d for player %d", targetTeam, playerID)
      return false
    end
  end
  
  -- Переводим игрока
  local success = Util.AssignPlayerToTeam(playerID, targetTeam)
  
  if success then
    Util.Log("INFO", "Player %d returned from spectators to team %d", playerID, targetTeam)
    
    -- Убираем из списка исключенных
    if _G.GVH_EliminatedPlayers then
      _G.GVH_EliminatedPlayers[playerID] = nil
    end
    
    -- Возрождаем героя если нужно
    Teams.RespawnPlayerHero(playerID)
  else
    Util.Log("ERROR", "Failed to return player %d from spectators", playerID)
  end
  
  return success
end

-- Возрождение героя игрока
function Teams.RespawnPlayerHero(playerID)
  if not Util.IsValidPlayerID(playerID) then
    return false
  end
  
  local hero = Util.GetPlayerHero(playerID)
  if hero and IsValidEntity(hero) then
    if hero:IsAlive() then
      Util.Log("DEBUG", "Player %d hero is already alive", playerID)
      return true
    end
    
    -- Сбрасываем время возрождения
    Util.SetRespawnTime(hero, 0)
    
    -- Принудительно возрождаем
    if hero.RespawnHero then
      Util.SafeCall(hero.RespawnHero, hero, false, false)
      Util.Log("DEBUG", "Respawned hero for player %d", playerID)
      return true
    end
  end
  
  return false
end

-- Проверка и исправление команд всех игроков
function Teams.ValidateAllPlayers()
  Util.Log("DEBUG", "Validating all player assignments...")
  
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if Util.IsValidPlayerID(playerID) then
      local team = Util.GetPlayerTeam(playerID)
      
      -- Если игрок в NOTEAM, назначаем его
      if team == GVH.TEAMS.NOTEAM then
        Util.Log("DEBUG", "Found unassigned player %d, assigning...", playerID)
        Teams.SafeAssign(playerID)
      end
      
      -- Проверяем переполнение команд
      local soloCount = Util.GetTeamPlayerCount(GVH.TEAM_SOLO)
      local hordeCount = Util.GetTeamPlayerCount(GVH.TEAM_HORDE)
      
      if soloCount > GVH.SOLO_SLOTS then
        Util.Log("WARN", "Solo team overfilled (%d/%d), moving excess to spectators", soloCount, GVH.SOLO_SLOTS)
        -- Логика перемещения лишних игроков
        Teams.HandleTeamOverflow(GVH.TEAM_SOLO, GVH.SOLO_SLOTS)
      end
      
      if hordeCount > GVH.HORDE_SLOTS then
        Util.Log("WARN", "Horde team overfilled (%d/%d), moving excess to spectators", hordeCount, GVH.HORDE_SLOTS)
        Teams.HandleTeamOverflow(GVH.TEAM_HORDE, GVH.HORDE_SLOTS)
      end
    end
  end
end

-- Обработка переполнения команды
function Teams.HandleTeamOverflow(teamID, maxPlayers)
  local playerList = {}
  
  -- Собираем всех игроков команды
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if Util.IsValidPlayerID(playerID) and Util.GetPlayerTeam(playerID) == teamID then
      table.insert(playerList, playerID)
    end
  end
  
  -- Перемещаем лишних в наблюдатели (последних подключившихся)
  local excessCount = #playerList - maxPlayers
  for i = 1, excessCount do
    local playerID = playerList[#playerList - i + 1]
    Util.Log("INFO", "Moving excess player %d from team %d to spectators", playerID, teamID)
    Teams.MoveToSpectators(playerID, "overflow")
  end
end

-- Получение статистики команд
function Teams.GetTeamStats()
  return {
    solo = {
      current = Util.GetTeamPlayerCount(GVH.TEAM_SOLO),
      max = Util.GetTeamMaxPlayers(GVH.TEAM_SOLO)
    },
    horde = {
      current = Util.GetTeamPlayerCount(GVH.TEAM_HORDE),
      max = Util.GetTeamMaxPlayers(GVH.TEAM_HORDE)
    },
    spectators = {
      current = Util.GetTeamPlayerCount(GVH.TEAMS.SPECTATOR),
      max = Util.GetTeamMaxPlayers(GVH.TEAMS.SPECTATOR)
    }
  }
end

return Teams