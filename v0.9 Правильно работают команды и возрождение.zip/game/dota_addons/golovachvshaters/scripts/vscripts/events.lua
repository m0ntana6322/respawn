-- Events handling module for GVH mod
-- Обработчики смерти героев, подключения игроков, запросов UI на смену команды

Events = {}

-- Регистрация всех обработчиков событий
function Events.RegisterAll()
  Util.Log("INFO", "Registering event handlers...")
  
  -- Изменения состояния игры
  ListenToGameEvent("game_rules_state_change", Dynamic_Wrap(Events, "OnGameStateChange"), nil)
  
  -- Смерть сущностей
  ListenToGameEvent("entity_killed", Dynamic_Wrap(Events, "OnEntityKilled"), nil)
  
  -- Подключение игроков
  ListenToGameEvent("player_connect_full", Dynamic_Wrap(Events, "OnPlayerConnectFull"), nil)
  
  -- Отключение игроков
  ListenToGameEvent("player_disconnect", Dynamic_Wrap(Events, "OnPlayerDisconnect"), nil)
  
  -- Кастомные события UI
  CustomGameEventManager:RegisterListener("ui_request_join_team", Dynamic_Wrap(Events, "OnUiRequestJoinTeam"))
  CustomGameEventManager:RegisterListener("ui_request_spectate", Dynamic_Wrap(Events, "OnUiRequestSpectate"))
  
  Util.Log("INFO", "Event handlers registered successfully")
end

-- Обработчик изменения состояния игры
function Events.OnGameStateChange(event)
  local newState = GameRules:State_Get()
  Util.Log("DEBUG", "Game state changed to: %d", newState)
  
  -- Устанавливаем лимиты команд в нужные моменты
  if newState == DOTA_GAMERULES_STATE_CUSTOM_GAME_SETUP then
    Util.Log("INFO", "Custom game setup - setting team limits")
    Teams.SetupLimits()
    
  elseif newState == DOTA_GAMERULES_STATE_HERO_SELECTION then
    Util.Log("INFO", "Hero selection started - validating player assignments")
    Teams.ValidateAllPlayers()
    
  elseif newState == DOTA_GAMERULES_STATE_PRE_GAME then
    Util.Log("INFO", "Pre-game phase - final team validation")
    Teams.ValidateAllPlayers()
    Events.PrintTeamStats()
    
  elseif newState == DOTA_GAMERULES_STATE_GAME_IN_PROGRESS then
    Util.Log("INFO", "Game started!")
    Events.PrintTeamStats()
  end
end

-- Обработчик смерти сущностей
function Events.OnEntityKilled(event)
  local killedIndex = event.entindex_killed
  if not killedIndex then
    return
  end
  
  local killedUnit = EntIndexToHScript(killedIndex)
  if not killedUnit then
    return
  end
  
  -- Проверяем, что это настоящий герой
  if not Util.IsRealHero(killedUnit) then
    return
  end
  
  local playerID = Util.GetUnitOwnerID(killedUnit)
  if not Util.IsValidPlayerID(playerID) then
    return
  end
  
  local playerTeam = Util.GetPlayerTeam(playerID)
  Util.Log("DEBUG", "Hero killed: player %d (team %s)", playerID, tostring(playerTeam))
  
  -- Переводим в наблюдатели только игроков из Horde команды
  if playerTeam == GVH.TEAM_HORDE then
    Util.Log("INFO", "Eliminating Horde player %d after death", playerID)
    Teams.MoveToSpectators(playerID, "death")
    
    -- Проверяем условие победы
    Events.CheckVictoryCondition()
  elseif playerTeam == GVH.TEAM_SOLO then
    Util.Log("INFO", "Solo player %d died - checking victory condition", playerID)
    Events.CheckVictoryCondition()
  end
end

-- Обработчик подключения игроков
function Events.OnPlayerConnectFull(event)
  local playerID = event.PlayerID or event.index
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "Invalid playerID in connect event: %s", tostring(playerID))
    return
  end
  
  Util.Log("INFO", "Player %d connected", playerID)
  
  -- Назначаем игрока в команду
  Teams.SafeAssign(playerID)
  
  -- Отправляем информацию о текущем состоянии
  Events.SendTeamInfoToPlayer(playerID)
end

-- Обработчик отключения игроков
function Events.OnPlayerDisconnect(event)
  local playerID = event.PlayerID
  if not Util.IsValidPlayerID(playerID) then
    return
  end
  
  Util.Log("INFO", "Player %d disconnected", playerID)
  
  -- Проверяем условие победы после отключения
  Events.CheckVictoryCondition()
end

-- Обработчик запроса на смену команды через UI
function Events.OnUiRequestJoinTeam(event)
  local data = event
  local playerID = data.player_id
  local targetTeam = data.team
  
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "Invalid playerID in UI join team request: %s", tostring(playerID))
    return
  end
  
  Util.Log("DEBUG", "Player %d requests to join team %s", playerID, tostring(targetTeam))
  
  local currentTeam = Util.GetPlayerTeam(playerID)
  
  -- Если игрок в наблюдателях, пытаемся вернуть его
  if currentTeam == GVH.TEAMS.SPECTATOR then
    local success = Teams.ReturnFromSpectators(playerID, targetTeam)
    Events.SendJoinTeamResponse(playerID, success, success and "Returned to game" or "Cannot return to game")
    return
  end
  
  -- Проверяем, можно ли переместить в указанную команду
  if targetTeam == GVH.TEAM_SOLO and Util.HasTeamSlots(GVH.TEAM_SOLO, 1) then
    local success = Util.AssignPlayerToTeam(playerID, GVH.TEAM_SOLO)
    Events.SendJoinTeamResponse(playerID, success, success and "Joined Solo team" or "Failed to join Solo team")
  elseif targetTeam == GVH.TEAM_HORDE and Util.HasTeamSlots(GVH.TEAM_HORDE, 1) then
    local success = Util.AssignPlayerToTeam(playerID, GVH.TEAM_HORDE)
    Events.SendJoinTeamResponse(playerID, success, success and "Joined Horde team" or "Failed to join Horde team")
  else
    Events.SendJoinTeamResponse(playerID, false, "No slots available in requested team")
  end
end

-- Обработчик запроса на переход в наблюдатели через UI
function Events.OnUiRequestSpectate(event)
  local data = event
  local playerID = data.player_id
  
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "Invalid playerID in UI spectate request: %s", tostring(playerID))
    return
  end
  
  Util.Log("DEBUG", "Player %d requests to spectate", playerID)
  
  local success = Teams.MoveToSpectators(playerID, "manual")
  Events.SendSpectateResponse(playerID, success, success and "Moved to spectators" or "Failed to move to spectators")
end

-- Отправка ответа на запрос смены команды
function Events.SendJoinTeamResponse(playerID, success, message)
  CustomGameEventManager:Send_ServerToPlayer(PlayerResource:GetPlayer(playerID), "join_team_response", {
    success = success,
    message = message
  })
end

-- Отправка ответа на запрос перехода в наблюдатели
function Events.SendSpectateResponse(playerID, success, message)
  CustomGameEventManager:Send_ServerToPlayer(PlayerResource:GetPlayer(playerID), "spectate_response", {
    success = success,
    message = message
  })
end

-- Отправка информации о командах игроку
function Events.SendTeamInfoToPlayer(playerID)
  if not Util.IsValidPlayerID(playerID) then
    return
  end
  
  local stats = Teams.GetTeamStats()
  local player = PlayerResource:GetPlayer(playerID)
  if player then
    CustomGameEventManager:Send_ServerToPlayer(player, "team_info_update", {
      solo = stats.solo,
      horde = stats.horde,
      spectators = stats.spectators,
      player_team = Util.GetPlayerTeam(playerID)
    })
  end
end

-- Отправка информации о командах всем игрокам
function Events.BroadcastTeamInfo()
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if Util.IsValidPlayerID(playerID) then
      Events.SendTeamInfoToPlayer(playerID)
    end
  end
end

-- Вывод статистики команд в лог
function Events.PrintTeamStats()
  local stats = Teams.GetTeamStats()
  Util.Log("INFO", "Team Stats - Solo: %d/%d, Horde: %d/%d, Spectators: %d/%d",
           stats.solo.current, stats.solo.max,
           stats.horde.current, stats.horde.max,
           stats.spectators.current, stats.spectators.max)
end

-- Проверка условий победы
function Events.CheckVictoryCondition()
  local soloCount = Util.GetTeamPlayerCount(GVH.TEAM_SOLO)
  local hordeCount = Util.GetTeamPlayerCount(GVH.TEAM_HORDE)
  
  -- Считаем только подключенных игроков
  local connectedSolo = 0
  local connectedHorde = 0
  
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if Util.IsValidPlayerID(playerID) and PlayerResource:GetConnectionState(playerID) == DOTA_CONNECTION_STATE_CONNECTED then
      local team = Util.GetPlayerTeam(playerID)
      if team == GVH.TEAM_SOLO then
        connectedSolo = connectedSolo + 1
      elseif team == GVH.TEAM_HORDE then
        connectedHorde = connectedHorde + 1
      end
    end
  end
  
  Util.Log("DEBUG", "Victory check - Connected Solo: %d, Connected Horde: %d", connectedSolo, connectedHorde)
  
  -- Проверяем условия победы
  if connectedSolo == 0 and connectedHorde > 0 then
    Util.Log("INFO", "Horde victory - Solo team eliminated!")
    Events.EndGame(GVH.TEAM_HORDE)
  elseif connectedHorde == 0 and connectedSolo > 0 then
    Util.Log("INFO", "Solo victory - Horde team eliminated!")
    Events.EndGame(GVH.TEAM_SOLO)
  elseif connectedSolo == 0 and connectedHorde == 0 then
    Util.Log("INFO", "Draw - both teams eliminated!")
    Events.EndGame(nil) -- Ничья
  end
end

-- Завершение игры
function Events.EndGame(winnerTeam)
  if winnerTeam then
    GameRules:SetGameWinner(winnerTeam)
    Util.Log("INFO", "Game ended - Winner: Team %d", winnerTeam)
  else
    GameRules:SetGameWinner(DOTA_TEAM_NOTEAM) -- Ничья
    Util.Log("INFO", "Game ended - Draw")
  end
end

return Events