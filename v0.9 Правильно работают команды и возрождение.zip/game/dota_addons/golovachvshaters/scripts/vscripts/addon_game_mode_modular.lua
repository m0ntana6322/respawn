-- Golovach vs Haters - режим 1v23 для Dota 2 Custom Game
-- Полная реализация согласно техническому заданию GVH_TZ_1v23.md

-- Подключаем все модули через dofile (альтернативный способ для Dota 2)
dofile("scripts/vscripts/config.lua")
dofile("scripts/vscripts/util.lua")
dofile("scripts/vscripts/teams.lua")
dofile("scripts/vscripts/events.lua")
dofile("scripts/vscripts/allpick.lua")
dofile("scripts/vscripts/balance.lua")

-- Основной класс игрового режима
if GVHGameMode == nil then
  GVHGameMode = class({})
end

-- Функция активации (вызывается движком)
function Activate()
  GameRules.GVH = GVHGameMode()
  GameRules.GVH:Init()
end

-- Инициализация игрового режима
function GVHGameMode:Init()
  Util.Log("INFO", "Initializing Golovach vs Haters game mode v1.2...")
  
  -- Проверяем, что конфиг загружен
  if not GVH then
    print("[GVH] [ERROR] Config not loaded! Cannot initialize game mode.")
    return
  end
  
  -- Предотвращаем повторную инициализацию
  if _G.gvh_initialized then
    Util.Log("WARN", "Game mode already initialized, skipping...")
    return
  end
  _G.gvh_initialized = true
  
  -- Инициализируем подсистемы
  self:InitializeSubsystems()
  
  Util.Log("INFO", "Golovach vs Haters game mode initialized successfully!")
  Util.Log("INFO", "Mode: %d vs %d (Solo vs Horde)", GVH.SOLO_SLOTS, GVH.HORDE_SLOTS)
end

-- Инициализация всех подсистем
function GVHGameMode:InitializeSubsystems()
  -- 1. Настройка лимитов команд (критично - делаем первым)
  Teams.SetupLimits()
  
  -- 2. Регистрация обработчиков событий
  Events.RegisterAll()
  
  -- 3. Настройка All Pick режима
  if GVH.ENABLE_ALL_PICK then
    AllPick.Setup()
  end
  
  -- 4. Инициализация системы балансировки
  Balance.Init()
  
  -- 5. Дополнительные настройки
  self:SetupGameRules()
  
  Util.Log("DEBUG", "All subsystems initialized")
end

-- Настройка основных правил игры
function GVHGameMode:SetupGameRules()
  -- Отключаем стандартные механики, которые могут мешать
  GameRules:SetHeroRespawnEnabled(true)
  GameRules:SetUseUniversalShopMode(false)
  GameRules:SetSameHeroSelectionEnabled(false)
  GameRules:SetHeroSelectionTime(90.0)
  
  -- Настройки для кастомной игры
  GameRules:SetCustomGameSetupAutoLaunchDelay(0)
  GameRules:SetCustomGameSetupTimeout(300) -- 5 минут на настройку
  
  -- Включаем паузы
  GameRules:SetPauseEnabled(true)
  
  Util.Log("DEBUG", "Game rules configured")
end

-- Получение информации о режиме (для отладки)
function GVHGameMode:GetModeInfo()
  return {
    name = "Golovach vs Haters",
    version = "1.2",
    mode = "1v23",
    solo_slots = GVH.SOLO_SLOTS,
    horde_slots = GVH.HORDE_SLOTS,
    max_spectators = GVH.MAX_SPECTATORS,
    all_pick_enabled = GVH.ENABLE_ALL_PICK,
    autofill_bots = GVH.AUTOFILL_BOTS,
    debug_mode = GVH.DEBUG_MODE
  }
end

-- Обработка команд консоли (для отладки)
function GVHGameMode:OnConsoleCommand(command, args)
  if command == "gvh_info" then
    local info = self:GetModeInfo()
    for key, value in pairs(info) do
      print(string.format("[GVH] %s: %s", key, tostring(value)))
    end
    
  elseif command == "gvh_balance" then
    local stats = Balance.GetBalanceStats()
    print(string.format("[GVH] Solo: %d/%d, Horde: %d/%d, Spectators: %d/%d", 
                       stats.teams.solo.current, stats.teams.solo.max,
                       stats.teams.horde.current, stats.teams.horde.max,
                       stats.teams.spectators.current, stats.teams.spectators.max))
    print(string.format("[GVH] Ready: %s", tostring(stats.ready)))
    if not stats.ready then
      print(string.format("[GVH] Issues: %s", table.concat(stats.issues, ", ")))
    end
    
  elseif command == "gvh_force_balance" then
    Balance.ForceBalance()
    print("[GVH] Force balance completed")
    
  elseif command == "gvh_validate" then
    Teams.ValidateAllPlayers()
    print("[GVH] Player validation completed")
    
  else
    print("[GVH] Available commands: gvh_info, gvh_balance, gvh_force_balance, gvh_validate")
  end
end

-- Регистрируем консольные команды
Convars:RegisterCommand("gvh_info", function() GameRules.GVH:OnConsoleCommand("gvh_info", {}) end, "Show GVH mode info", 0)
Convars:RegisterCommand("gvh_balance", function() GameRules.GVH:OnConsoleCommand("gvh_balance", {}) end, "Show balance stats", 0)
Convars:RegisterCommand("gvh_force_balance", function() GameRules.GVH:OnConsoleCommand("gvh_force_balance", {}) end, "Force team balance", 0)
Convars:RegisterCommand("gvh_validate", function() GameRules.GVH:OnConsoleCommand("gvh_validate", {}) end, "Validate all players", 0)
