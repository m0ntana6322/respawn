-- Golovach vs Haters - режим 1v23 для Dota 2 Custom Game
-- Монолитная версия - весь код в одном файле для избежания проблем с модулями
-- Полная реализация согласно техническому заданию GVH_TZ_1v23.md

-- ============================================================================
-- КОНФИГУРАЦИЯ (config.lua)
-- ============================================================================

GVH = {
  -- Команды (используем числовые константы для надежности)
  TEAM_SOLO = 2,      -- DOTA_TEAM_GOODGUYS (Radiant)
  TEAM_HORDE = 3,     -- DOTA_TEAM_BADGUYS (Dire)
  
  -- Лимиты слотов
  SOLO_SLOTS = 1,
  HORDE_SLOTS = 23,
  
  -- Наблюдатели
  MAX_SPECTATORS = 40,              -- лимит наблюдателей (40 слотов)
  ALLOW_SPECTATOR_RETURN = true,    -- разрешить возврат из наблюдателей
  
  -- All Pick настройки
  ENABLE_ALL_PICK = true,
  PICKING_TIME = 75,                -- время на выбор героя (секунды)
  STRATEGY_TIME = 30,               -- время стратегии
  SHOWCASE_TIME = 5,                -- время показа героев
  
  -- Экономика
  STARTING_GOLD = 625,              -- стартовое золото
  GPM_MULTIPLIER = 1.2,             -- множитель GPM
  XPM_MULTIPLIER = 1.0,             -- множитель XPM
  
  -- Руны
  ENABLE_RUNES = true,
  POWER_RUNE_INTERVAL = 120,        -- интервал рун силы (секунды)
  WATER_RUNE_INTERVAL = 120,        -- интервал водных рун
  
  -- Лотосы
  ENABLE_LOTUS = true,
  
  -- Отладка
  DEBUG_MODE = false,               -- включить отладочные сообщения
  LOG_PREFIX = "[GVH]"              -- префикс для логов
}

-- Константы команд для удобства (числовые значения)
GVH.TEAMS = {
  SPECTATOR = 1,  -- DOTA_TEAM_SPECTATOR
  SOLO = 2,       -- DOTA_TEAM_GOODGUYS
  HORDE = 3,      -- DOTA_TEAM_BADGUYS
  NOTEAM = 5      -- DOTA_TEAM_NOTEAM
}

-- ============================================================================
-- УТИЛИТЫ (util.lua)
-- ============================================================================

Util = {}

-- Проверка валидности ID игрока
function Util.IsValidPlayerID(playerID)
  if type(playerID) ~= "number" or playerID < 0 or playerID > 23 then
    return false
  end
  
  -- Проверяем через PlayerResource если он доступен
  if PlayerResource and PlayerResource.IsValidPlayerID then
    return PlayerResource:IsValidPlayerID(playerID)
  end
  
  return true -- Если PlayerResource недоступен, считаем ID валидным
end

-- Безопасное логирование с префиксом
function Util.Log(level, message, ...)
  if not GVH or not GVH.LOG_PREFIX then
    print(string.format("[GVH] %s: %s", level, string.format(message, ...)))
    return
  end
  
  -- Проверяем уровень отладки
  if level == "DEBUG" and not GVH.DEBUG_MODE then
    return
  end
  
  local formattedMessage = string.format(message, ...)
  print(string.format("%s [%s] %s", GVH.LOG_PREFIX, level, formattedMessage))
end

-- Безопасный вызов функции с обработкой ошибок
function Util.SafeCall(func, ...)
  local success, result = pcall(func, ...)
  if not success then
    Util.Log("ERROR", "API call failed: %s", tostring(result))
    return nil
  end
  return result
end

-- Получение количества игроков в команде (безопасно)
function Util.GetTeamPlayerCount(teamID)
  if not teamID or type(teamID) ~= "number" then
    Util.Log("ERROR", "GetTeamPlayerCount: invalid teamID %s", tostring(teamID))
    return 0
  end
  
  -- Используем правильный API
  if PlayerResource and PlayerResource.IsValidPlayerID then
    local count = 0
    -- Проверяем всех возможных игроков (обычно 0-23)
    for playerID = 0, 23 do
      if PlayerResource:IsValidPlayerID(playerID) and PlayerResource:GetTeam(playerID) == teamID then
        count = count + 1
      end
    end
    return count
  end
  
  return 0
end

-- Получение максимального количества игроков в команде (безопасно)
function Util.GetTeamMaxPlayers(teamID)
  if not teamID or type(teamID) ~= "number" then
    Util.Log("ERROR", "GetTeamMaxPlayers: invalid teamID %s", tostring(teamID))
    return 0
  end
  
  -- Используем правильный API
  if GameRules and GameRules.GetCustomGameTeamMaxPlayers then
    return Util.SafeCall(GameRules.GetCustomGameTeamMaxPlayers, GameRules, teamID) or 0
  end
  
  return 0
end

-- Установка лимита команды (безопасно)
function Util.SetTeamMaxPlayers(teamID, maxPlayers)
  if not teamID or type(teamID) ~= "number" then
    Util.Log("ERROR", "SetTeamMaxPlayers: invalid teamID %s", tostring(teamID))
    return false
  end
  
  if not maxPlayers or type(maxPlayers) ~= "number" or maxPlayers < 0 then
    Util.Log("ERROR", "SetTeamMaxPlayers: invalid maxPlayers %s", tostring(maxPlayers))
    return false
  end
  
  -- Используем правильный API
  if GameRules and GameRules.SetCustomGameTeamMaxPlayers then
    local success = Util.SafeCall(GameRules.SetCustomGameTeamMaxPlayers, GameRules, teamID, maxPlayers)
    if success ~= nil then
      Util.Log("DEBUG", "Set team %d max players to %d", teamID, maxPlayers)
      return true
    end
  end
  
  return false
end

-- Назначение игрока в команду (безопасно)
function Util.AssignPlayerToTeam(playerID, teamID)
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "AssignPlayerToTeam: invalid playerID %s", tostring(playerID))
    return false
  end
  
  if not teamID or type(teamID) ~= "number" then
    Util.Log("ERROR", "AssignPlayerToTeam: invalid teamID %s", tostring(teamID))
    return false
  end
  
  -- Используем правильный API для назначения команды
  if PlayerResource and PlayerResource.SetCustomTeamAssignment then
    local success = Util.SafeCall(PlayerResource.SetCustomTeamAssignment, PlayerResource, playerID, teamID)
    if success ~= nil then
      Util.Log("DEBUG", "Assigned player %d to team %d", playerID, teamID)
      return true
    end
  end
  
  -- Альтернативный способ через GameRules
  if GameRules and GameRules.SetCustomGameTeamMaxPlayers then
    -- Сначала убеждаемся, что в команде есть место
    local currentCount = Util.GetTeamPlayerCount(teamID)
    local maxCount = Util.GetTeamMaxPlayers(teamID)
    
    if currentCount < maxCount then
      -- Используем PlayerResource:SetTeam напрямую
      if PlayerResource.SetTeam then
        PlayerResource:SetTeam(playerID, teamID)
        Util.Log("DEBUG", "Assigned player %d to team %d (direct)", playerID, teamID)
        return true
      end
    else
      Util.Log("WARN", "Team %d is full (%d/%d), cannot assign player %d", teamID, currentCount, maxCount, playerID)
    end
  end
  
  return false
end

-- Получение команды игрока (безопасно)
function Util.GetPlayerTeam(playerID)
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "GetPlayerTeam: invalid playerID %s", tostring(playerID))
    return nil
  end
  
  return Util.SafeCall(PlayerResource.GetTeam, PlayerResource, playerID)
end

-- ============================================================================
-- УПРАВЛЕНИЕ КОМАНДАМИ (teams.lua)
-- ============================================================================

Teams = {}

-- Инициализация лимитов команд
function Teams.SetupLimits()
  Util.Log("INFO", "Setting up team limits...")
  
  -- Проверяем, что конфиг загружен
  if not GVH or not GVH.SOLO_SLOTS or not GVH.HORDE_SLOTS then
    Util.Log("ERROR", "Config not loaded! Cannot set team limits.")
    return false
  end
  
  -- Проверяем, что GameRules готов
  if not GameRules or not GameRules.SetCustomGameTeamMaxPlayers then
    Util.Log("WARN", "GameRules not ready, deferring team limits setup...")
    -- Отложим инициализацию на потом
    if GameRules and GameRules:GetGameModeEntity() then
      GameRules:GetGameModeEntity():SetThink(Teams.SetupLimits, "setup_limits", 1.0)
    end
    return false
  end
  
  -- Устанавливаем лимиты команд
  local success = true
  success = success and Util.SetTeamMaxPlayers(GVH.TEAM_SOLO, GVH.SOLO_SLOTS)
  success = success and Util.SetTeamMaxPlayers(GVH.TEAM_HORDE, GVH.HORDE_SLOTS)
  success = success and Util.SetTeamMaxPlayers(GVH.TEAMS.SPECTATOR, GVH.MAX_SPECTATORS)
  
  if success then
    Util.Log("INFO", "Team limits set: Solo=%d, Horde=%d, Spectators=%d", 
             GVH.SOLO_SLOTS, GVH.HORDE_SLOTS, GVH.MAX_SPECTATORS)
  else
    Util.Log("ERROR", "Failed to set some team limits")
  end
  
  return success
end

-- Безопасное назначение игрока в команду с учетом лимитов
function Teams.SafeAssign(playerID)
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "SafeAssign: invalid playerID %s", tostring(playerID))
    return false
  end
  
  local currentTeam = Util.GetPlayerTeam(playerID)
  Util.Log("DEBUG", "SafeAssign: player %d currently in team %s", playerID, tostring(currentTeam))
  
  -- Если игрок уже в правильной команде, ничего не делаем
  if currentTeam == GVH.TEAM_SOLO or currentTeam == GVH.TEAM_HORDE then
    Util.Log("DEBUG", "Player %d already in correct team %d", playerID, currentTeam)
    return true
  end
  
  -- Пытаемся назначить в Solo команду (приоритет)
  local soloCount = Util.GetTeamPlayerCount(GVH.TEAM_SOLO)
  Util.Log("DEBUG", "Solo team count: %d/%d", soloCount, GVH.SOLO_SLOTS)
  
  if soloCount < GVH.SOLO_SLOTS then
    Util.Log("INFO", "Assigning player %d to Solo team (slot %d/%d)", playerID, soloCount + 1, GVH.SOLO_SLOTS)
    return Util.AssignPlayerToTeam(playerID, GVH.TEAM_SOLO)
  end
  
  -- Пытаемся назначить в Horde команду
  local hordeCount = Util.GetTeamPlayerCount(GVH.TEAM_HORDE)
  Util.Log("DEBUG", "Horde team count: %d/%d", hordeCount, GVH.HORDE_SLOTS)
  
  if hordeCount < GVH.HORDE_SLOTS then
    Util.Log("INFO", "Assigning player %d to Horde team (slot %d/%d)", playerID, hordeCount + 1, GVH.HORDE_SLOTS)
    return Util.AssignPlayerToTeam(playerID, GVH.TEAM_HORDE)
  end
  
  -- Если обе команды заполнены, отправляем в наблюдатели
  Util.Log("INFO", "Both teams full (Solo: %d/%d, Horde: %d/%d), assigning player %d to spectators", 
           soloCount, GVH.SOLO_SLOTS, hordeCount, GVH.HORDE_SLOTS, playerID)
  return Teams.MoveToSpectators(playerID)
end

-- Перевод игрока в наблюдатели
function Teams.MoveToSpectators(playerID)
  if not Util.IsValidPlayerID(playerID) then
    return false
  end
  
  -- Расширяем лимит наблюдателей если нужно
  local spectatorCount = Util.GetTeamPlayerCount(GVH.TEAMS.SPECTATOR)
  local maxSpectators = Util.GetTeamMaxPlayers(GVH.TEAMS.SPECTATOR)
  
  if spectatorCount >= maxSpectators then
    -- Не увеличиваем лимит наблюдателей, он уже установлен в 40
    Util.Log("WARN", "Spectator slots full (%d/%d), cannot add more", spectatorCount, maxSpectators)
    return false
  end
  
  return Util.AssignPlayerToTeam(playerID, GVH.TEAMS.SPECTATOR)
end

-- Настройка возрождения для всех героев
function Teams.SetupRespawnRules()
  Util.Log("INFO", "Setting up respawn rules...")
  
  for playerID = 0, 23 do
    if PlayerResource:IsValidPlayerID(playerID) then
      local team = Util.GetPlayerTeam(playerID)
      local hero = PlayerResource:GetSelectedHeroEntity(playerID)
      
      if hero and team then
        if team == GVH.TEAM_HORDE then
          -- Horde игроки не возрождаются
          hero:SetRespawnsDisabled(true)
          Util.Log("DEBUG", "Disabled respawn for Horde player %d", playerID)
        elseif team == GVH.TEAM_SOLO then
          -- Solo игрок возрождается
          hero:SetRespawnsDisabled(false)
          Util.Log("DEBUG", "Enabled respawn for Solo player %d", playerID)
        end
      end
    end
  end
end

-- ============================================================================
-- ОСНОВНОЙ КЛАСС ИГРОВОГО РЕЖИМА
-- ============================================================================

if GVHGameMode == nil then
  GVHGameMode = class({})
end

function GVHGameMode:Init()
  Util.Log("INFO", "Initializing Golovach vs Haters game mode v1.2...")
  
  -- Инициализируем подсистемы
  self:InitializeSubsystems()
  
  -- Регистрируем обработчики событий
  self:RegisterEventHandlers()
  
  -- Регистрируем консольные команды
  self:RegisterConsoleCommands()
  
  Util.Log("INFO", "Game mode initialization complete")
end

function GVHGameMode:InitializeSubsystems()
  Util.Log("DEBUG", "Initializing subsystems...")
  
  -- Настройка лимитов команд
  Teams.SetupLimits()
  
  -- Настройка All Pick режима
  if GVH.ENABLE_ALL_PICK then
    self:SetupAllPick()
  end
  
  Util.Log("DEBUG", "Subsystems initialized")
end

function GVHGameMode:SetupAllPick()
  Util.Log("INFO", "Setting up All Pick mode...")
  
  -- Настройки игрового режима
  if GameRules then
    GameRules:SetHeroRespawnEnabled(true)  -- Включаем возрождение (будем контролировать вручную)
    GameRules:SetUseUniversalShopMode(true)
    GameRules:SetSameHeroSelectionEnabled(true)
    GameRules:SetHeroSelectionTime(GVH.PICKING_TIME)
    GameRules:SetPreGameTime(GVH.STRATEGY_TIME)
    GameRules:SetShowcaseTime(GVH.SHOWCASE_TIME)
    GameRules:SetStartingGold(GVH.STARTING_GOLD)
    GameRules:SetGoldPerTick(math.floor(GVH.GPM_MULTIPLIER * 100))
    
    -- КРИТИЧЕСКИ ВАЖНО: Устанавливаем лимиты команд СРАЗУ
    GameRules:SetCustomGameTeamMaxPlayers(GVH.TEAM_SOLO, GVH.SOLO_SLOTS)
    GameRules:SetCustomGameTeamMaxPlayers(GVH.TEAM_HORDE, GVH.HORDE_SLOTS)
    GameRules:SetCustomGameTeamMaxPlayers(GVH.TEAMS.SPECTATOR, GVH.MAX_SPECTATORS)
    
    Util.Log("INFO", "FORCED team limits: Solo=%d, Horde=%d, Spectators=%d", 
             GVH.SOLO_SLOTS, GVH.HORDE_SLOTS, GVH.MAX_SPECTATORS)
    
    Util.Log("DEBUG", "Game mode parameters set")
  end
  
  -- Настройка рун
  if GVH.ENABLE_RUNES then
    GameRules:SetRuneSpawnTime(GVH.POWER_RUNE_INTERVAL)
    Util.Log("DEBUG", "Runes setup: Power every %ds, Water every %ds", 
             GVH.POWER_RUNE_INTERVAL, GVH.WATER_RUNE_INTERVAL)
  end
  
  Util.Log("INFO", "All Pick mode configured")
end

function GVHGameMode:RegisterEventHandlers()
  Util.Log("DEBUG", "Registering event handlers...")
  
  -- Подключение игрока
  ListenToGameEvent("player_connect_full", function(event)
    local playerID = event.PlayerID
    Util.Log("INFO", "Player %d connected", playerID)
    Teams.SafeAssign(playerID)
  end, nil)
  
  -- Смерть героя
  ListenToGameEvent("entity_killed", function(event)
    local killedUnit = EntIndexToHScript(event.entindex_killed)
    if killedUnit and killedUnit:IsRealHero() then
      local playerID = killedUnit:GetPlayerOwnerID()
      local team = Util.GetPlayerTeam(playerID)
      
      -- Если умер игрок из Horde команды, переводим в наблюдатели
      if team == GVH.TEAM_HORDE then
        Util.Log("INFO", "Horde player %d died, moving to spectators", playerID)
        Teams.MoveToSpectators(playerID)
      elseif team == GVH.TEAM_SOLO then
        Util.Log("INFO", "Solo player %d died, will respawn normally", playerID)
        -- Solo игрок возрождается автоматически (HeroRespawnEnabled = true)
      end
    end
  end, nil)
  
  -- Контроль возрождения героев
  ListenToGameEvent("dota_player_pick_hero", function(event)
    local playerID = event.player
    local team = Util.GetPlayerTeam(playerID)
    
    Util.Log("DEBUG", "Player %d picked hero, team: %d", playerID, team or -1)
  end, nil)
  
  -- Обработка возрождения героев
  ListenToGameEvent("dota_player_gained_level", function(event)
    -- Используем это событие для отложенной настройки героя
    local playerID = event.player
    local team = Util.GetPlayerTeam(playerID)
    local hero = PlayerResource:GetSelectedHeroEntity(playerID)
    
    if hero and team then
      if team == GVH.TEAM_HORDE then
        -- Для Horde игроков отключаем возрождение
        hero:SetRespawnsDisabled(true)
        Util.Log("DEBUG", "Disabled respawn for Horde player %d", playerID)
      elseif team == GVH.TEAM_SOLO then
        -- Solo игрок может возрождаться
        hero:SetRespawnsDisabled(false)
        Util.Log("DEBUG", "Enabled respawn for Solo player %d", playerID)
      end
    end
  end, nil)
  
  -- Изменение состояния игры
  ListenToGameEvent("game_rules_state_change", function(event)
    local newState = GameRules:State_Get()
    Util.Log("DEBUG", "Game state changed to: %d", newState)
    
    if newState == DOTA_GAMERULES_STATE_CUSTOM_GAME_SETUP then
      Util.Log("INFO", "Custom game setup - setting team limits")
      Teams.SetupLimits()
    end
  end, nil)
  
  Util.Log("INFO", "Event handlers registered successfully")
end

function GVHGameMode:RegisterConsoleCommands()
  Convars:RegisterCommand("gvh_info", function()
    print("=== Golovach vs Haters v1.2 ===")
    print("Mode: 1 vs 23 (Solo vs Horde)")
    print("Solo team: " .. Util.GetTeamPlayerCount(GVH.TEAM_SOLO) .. "/" .. GVH.SOLO_SLOTS)
    print("Horde team: " .. Util.GetTeamPlayerCount(GVH.TEAM_HORDE) .. "/" .. GVH.HORDE_SLOTS)
    print("Spectators: " .. Util.GetTeamPlayerCount(GVH.TEAMS.SPECTATOR) .. "/" .. Util.GetTeamMaxPlayers(GVH.TEAMS.SPECTATOR))
  end, "Show GVH mode information", 0)
  
  Convars:RegisterCommand("gvh_balance", function()
    print("=== Team Balance ===")
    for playerID = 0, 23 do
      if PlayerResource:IsValidPlayerID(playerID) then
        local team = Util.GetPlayerTeam(playerID)
        local teamName = "Unknown"
        if team == GVH.TEAM_SOLO then teamName = "Solo"
        elseif team == GVH.TEAM_HORDE then teamName = "Horde"
        elseif team == GVH.TEAMS.SPECTATOR then teamName = "Spectator"
        elseif team == GVH.TEAMS.NOTEAM then teamName = "NOTEAM"
        end
        print(string.format("Player %d: Team %d (%s)", playerID, team, teamName))
      end
    end
  end, "Show team balance", 0)
  
  Util.Log("DEBUG", "Console commands registered")
end

-- ============================================================================
-- ИНИЦИАЛИЗАЦИЯ
-- ============================================================================

function Activate()
  GVHGameMode:Init()
end

function Precache(context)
  -- Здесь можно добавить прекэширование ресурсов
end