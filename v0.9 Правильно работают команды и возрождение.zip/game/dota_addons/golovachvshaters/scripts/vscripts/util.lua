-- Utility functions for GVH mod
-- Безопасные вызовы API, логирование, валидация

Util = {}

-- Проверка валидности ID игрока
function Util.IsValidPlayerID(playerID)
  if type(playerID) ~= "number" or playerID < 0 or playerID > 23 then
    return false
  end
  
  -- Проверяем через PlayerResource если он доступен
  if PlayerResource and PlayerResource.IsValidPlayerID then
    return PlayerResource:IsValidPlayerID(playerID)
  end
  
  return true -- Если PlayerResource недоступен, считаем ID валидным
end

-- Безопасное логирование с префиксом
function Util.Log(level, message, ...)
  if not GVH or not GVH.LOG_PREFIX then
    print("[GVH] " .. tostring(message))
    return
  end
  
  local prefix = GVH.LOG_PREFIX
  local fullMessage = string.format(tostring(message), ...)
  
  if level == "ERROR" then
    print(prefix .. " [ERROR] " .. fullMessage)
  elseif level == "WARN" then
    print(prefix .. " [WARN] " .. fullMessage)
  elseif level == "DEBUG" and GVH.DEBUG_MODE then
    print(prefix .. " [DEBUG] " .. fullMessage)
  else
    print(prefix .. " " .. fullMessage)
  end
end

-- Безопасный вызов API функций с обработкой ошибок
function Util.SafeCall(func, ...)
  local success, result = pcall(func, ...)
  if not success then
    Util.Log("ERROR", "API call failed: %s", tostring(result))
    return nil
  end
  return result
end

-- Получение количества игроков в команде (безопасно)
function Util.GetTeamPlayerCount(teamID)
  if not teamID or type(teamID) ~= "number" then
    Util.Log("ERROR", "GetTeamPlayerCount: invalid teamID %s", tostring(teamID))
    return 0
  end
  
  -- Используем правильный API
  if PlayerResource and PlayerResource.IsValidPlayerID then
    local count = 0
    -- Проверяем всех возможных игроков (обычно 0-23)
    for playerID = 0, 23 do
      if PlayerResource:IsValidPlayerID(playerID) and PlayerResource:GetTeam(playerID) == teamID then
        count = count + 1
      end
    end
    return count
  end
  
  return 0
end

-- Получение максимального количества игроков в команде (безопасно)
function Util.GetTeamMaxPlayers(teamID)
  if not teamID or type(teamID) ~= "number" then
    Util.Log("ERROR", "GetTeamMaxPlayers: invalid teamID %s", tostring(teamID))
    return 0
  end
  
  -- Используем правильный API
  if GameRules and GameRules.GetCustomGameTeamMaxPlayers then
    return Util.SafeCall(GameRules.GetCustomGameTeamMaxPlayers, GameRules, teamID) or 0
  end
  
  return 0
end

-- Установка лимита команды (безопасно)
function Util.SetTeamMaxPlayers(teamID, maxPlayers)
  if not teamID or type(teamID) ~= "number" then
    Util.Log("ERROR", "SetTeamMaxPlayers: invalid teamID %s", tostring(teamID))
    return false
  end
  
  if not maxPlayers or type(maxPlayers) ~= "number" or maxPlayers < 0 then
    Util.Log("ERROR", "SetTeamMaxPlayers: invalid maxPlayers %s", tostring(maxPlayers))
    return false
  end
  
  -- Используем правильный API
  if GameRules and GameRules.SetCustomGameTeamMaxPlayers then
    local success = Util.SafeCall(GameRules.SetCustomGameTeamMaxPlayers, GameRules, teamID, maxPlayers)
    if success ~= nil then
      Util.Log("DEBUG", "Set team %d max players to %d", teamID, maxPlayers)
      return true
    end
  end
  
  return false
end

-- Назначение игрока в команду (безопасно)
function Util.AssignPlayerToTeam(playerID, teamID)
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "AssignPlayerToTeam: invalid playerID %s", tostring(playerID))
    return false
  end
  
  if not teamID or type(teamID) ~= "number" then
    Util.Log("ERROR", "AssignPlayerToTeam: invalid teamID %s", tostring(teamID))
    return false
  end
  
  -- Используем правильный API для назначения команды
  if PlayerResource and PlayerResource.SetCustomTeamAssignment then
    local success = Util.SafeCall(PlayerResource.SetCustomTeamAssignment, PlayerResource, playerID, teamID)
    if success ~= nil then
      Util.Log("DEBUG", "Assigned player %d to team %d", playerID, teamID)
      return true
    end
  end
  
  -- Альтернативный способ через GameRules
  if GameRules and GameRules.SetCustomGameTeamMaxPlayers then
    -- Сначала убеждаемся, что в команде есть место
    local currentCount = Util.GetTeamPlayerCount(teamID)
    local maxCount = Util.GetTeamMaxPlayers(teamID)
    
    if currentCount < maxCount then
      -- Используем PlayerResource:SetTeam напрямую
      if PlayerResource.SetTeam then
        PlayerResource:SetTeam(playerID, teamID)
        Util.Log("DEBUG", "Assigned player %d to team %d (direct)", playerID, teamID)
        return true
      end
    else
      Util.Log("WARN", "Team %d is full (%d/%d), cannot assign player %d", teamID, currentCount, maxCount, playerID)
    end
  end
  
  return false
end

-- Получение команды игрока (безопасно)
function Util.GetPlayerTeam(playerID)
  if not Util.IsValidPlayerID(playerID) then
    Util.Log("ERROR", "GetPlayerTeam: invalid playerID %s", tostring(playerID))
    return nil
  end
  
  return Util.SafeCall(PlayerResource.GetTeam, PlayerResource, playerID)
end

-- Проверка, есть ли свободные слоты в команде
function Util.HasTeamSlots(teamID, slotsNeeded)
  slotsNeeded = slotsNeeded or 1
  local currentCount = Util.GetTeamPlayerCount(teamID)
  local maxCount = Util.GetTeamMaxPlayers(teamID)
  
  return (currentCount + slotsNeeded) <= maxCount
end

-- Расширение лимита наблюдателей при необходимости
function Util.EnsureSpectatorSlots(slotsNeeded)
  slotsNeeded = slotsNeeded or 1
  local currentSpectators = Util.GetTeamPlayerCount(GVH.TEAMS.SPECTATOR)
  local maxSpectators = Util.GetTeamMaxPlayers(GVH.TEAMS.SPECTATOR)
  
  if (currentSpectators + slotsNeeded) > maxSpectators then
    local newMax = currentSpectators + slotsNeeded
    -- Ограничиваем максимум разумным числом
    if newMax > 64 then
      newMax = 64
    end
    
    Util.Log("INFO", "Expanding spectator slots from %d to %d", maxSpectators, newMax)
    return Util.SetTeamMaxPlayers(GVH.TEAMS.SPECTATOR, newMax)
  end
  
  return true
end

-- Получение героя игрока (безопасно)
function Util.GetPlayerHero(playerID)
  if not Util.IsValidPlayerID(playerID) then
    return nil
  end
  
  return Util.SafeCall(PlayerResource.GetSelectedHeroEntity, PlayerResource, playerID)
end

-- Проверка, является ли юнит настоящим героем
function Util.IsRealHero(unit)
  if not unit or not IsValidEntity(unit) then
    return false
  end
  
  return unit:IsRealHero()
end

-- Получение ID владельца юнита
function Util.GetUnitOwnerID(unit)
  if not unit or not IsValidEntity(unit) then
    return nil
  end
  
  return Util.SafeCall(unit.GetPlayerOwnerID, unit)
end

-- Удаление юнита (безопасно)
function Util.RemoveUnit(unit)
  if not unit or not IsValidEntity(unit) then
    return false
  end
  
  return Util.SafeCall(UTIL_Remove, unit) ~= nil
end

-- Установка времени до возрождения (безопасно)
function Util.SetRespawnTime(unit, time)
  if not unit or not IsValidEntity(unit) then
    return false
  end
  
  if unit.SetTimeUntilRespawn then
    return Util.SafeCall(unit.SetTimeUntilRespawn, unit, time) ~= nil
  end
  
  return false
end

return Util