-- All Pick mode setup for GVH mod
-- Стандартные настройки All Pick: руны, лотосы, GPM/XPM, тайминги

AllPick = {}

-- Инициализация режима All Pick
function AllPick.Setup()
  if not GVH.ENABLE_ALL_PICK then
    Util.Log("INFO", "All Pick mode disabled in config")
    return
  end
  
  Util.Log("INFO", "Setting up All Pick mode...")
  
  AllPick.SetupGameMode()
  AllPick.SetupEconomy()
  AllPick.SetupRunes()
  AllPick.SetupLotus()
  AllPick.SetupTimings()
  
  Util.Log("INFO", "All Pick mode setup completed")
end

-- Настройка основных параметров игрового режима
function AllPick.SetupGameMode()
  local gameMode = GameRules:GetGameModeEntity()
  if not gameMode then
    Util.Log("ERROR", "Cannot get GameModeEntity")
    return
  end
  
  -- Отключаем драфт и баны
  Util.SafeCall(gameMode.SetDraftingBanningTimeOverride, gameMode, 0)
  
  -- Включаем All Pick
  Util.SafeCall(GameRules.SetGameMode, GameRules, DOTA_GAMEMODE_ALL_PICK)
  
  -- Настройки героев
  Util.SafeCall(gameMode.SetRecommendedItemsDisabled, gameMode, false)
  Util.SafeCall(gameMode.SetCameraDistanceOverride, gameMode, 1134.0)
  
  -- Отключаем некоторые стандартные механики
  Util.SafeCall(gameMode.SetBuybackEnabled, gameMode, true)
  Util.SafeCall(gameMode.SetTopBarTeamValuesOverride, gameMode, true)
  Util.SafeCall(gameMode.SetTopBarTeamValuesVisible, gameMode, false)
  
  Util.Log("DEBUG", "Game mode parameters set")
end

-- Настройка экономики (золото и опыт)
function AllPick.SetupEconomy()
  local gameMode = GameRules:GetGameModeEntity()
  if not gameMode then
    return
  end
  
  -- Настройка золота
  local goldPerTick = GVH.GOLD_PER_MIN / 60.0 -- Конвертируем в золото за секунду
  Util.SafeCall(gameMode.SetGoldPerTick, gameMode, goldPerTick)
  Util.SafeCall(gameMode.SetGoldTickTime, gameMode, 1.0) -- Каждую секунду
  
  -- Стартовое золото
  Util.SafeCall(gameMode.SetCustomGameForceHero, gameMode, "")
  
  -- Настройка опыта
  if GVH.XP_MULT ~= 1.0 then
    Util.SafeCall(gameMode.SetXPPerLevelTable, gameMode, AllPick.GetCustomXPTable())
  end
  
  Util.Log("DEBUG", "Economy setup: %d GPM, XP multiplier: %.1f", GVH.GOLD_PER_MIN, GVH.XP_MULT)
end

-- Получение кастомной таблицы опыта
function AllPick.GetCustomXPTable()
  local xpTable = {}
  local baseXP = {
    0, 200, 500, 900, 1400, 2000, 2700, 3500, 4400, 5400,
    6500, 7700, 9000, 10400, 11900, 13500, 15200, 17000, 18900, 20900,
    23000, 25200, 27500, 29900, 32400, 35000, 37700, 40500, 43400, 46400
  }
  
  for i, xp in ipairs(baseXP) do
    xpTable[i] = math.floor(xp * GVH.XP_MULT)
  end
  
  return xpTable
end

-- Настройка рун
function AllPick.SetupRunes()
  local gameMode = GameRules:GetGameModeEntity()
  if not gameMode then
    return
  end
  
  -- Включаем руны силы
  Util.SafeCall(gameMode.SetPowerRuneSpawnInterval, gameMode, GVH.POWER_RUNE_INTERVAL)
  
  -- Включаем водные руны
  if gameMode.SetWaterRuneSpawnInterval then
    Util.SafeCall(gameMode.SetWaterRuneSpawnInterval, gameMode, GVH.WATER_RUNE_INTERVAL)
  end
  
  -- Включаем все типы рун силы
  local powerRunes = {
    DOTA_RUNE_DOUBLEDAMAGE,
    DOTA_RUNE_HASTE,
    DOTA_RUNE_ILLUSION,
    DOTA_RUNE_INVISIBILITY,
    DOTA_RUNE_REGENERATION,
    DOTA_RUNE_ARCANE
  }
  
  for _, runeType in ipairs(powerRunes) do
    if gameMode.SetRuneEnabled then
      Util.SafeCall(gameMode.SetRuneEnabled, gameMode, runeType, true)
    end
  end
  
  -- Включаем баунти руны
  if gameMode.SetBountyRuneSpawnInterval then
    Util.SafeCall(gameMode.SetBountyRuneSpawnInterval, gameMode, 300) -- Каждые 5 минут
  end
  
  Util.Log("DEBUG", "Runes setup: Power every %ds, Water every %ds", 
           GVH.POWER_RUNE_INTERVAL, GVH.WATER_RUNE_INTERVAL)
end

-- Настройка лотосов
function AllPick.SetupLotus()
  if not GVH.ENABLE_LOTUS then
    Util.Log("DEBUG", "Lotus pools disabled in config")
    return
  end
  
  -- Создаем таймер для лотосов через GameModeEntity
  local function LotusTimer()
    AllPick.SpawnLotusItems()
    return 300 -- Повторяем каждые 5 минут
  end
  
  -- Запускаем таймер
  if GameRules and GameRules:GetGameModeEntity() then
    GameRules:GetGameModeEntity():SetThink(LotusTimer, "lotus_timer", 60) -- Первый спавн через минуту
  end
  
  Util.Log("DEBUG", "Lotus pools enabled")
end

-- Спавн предметов в лотосах
function AllPick.SpawnLotusItems()
  -- Список возможных предметов в лотосах
  local lotusItems = {
    "item_tango",
    "item_healing_salve",
    "item_clarity",
    "item_enchanted_mango",
    "item_faerie_fire",
    "item_flask"
  }
  
  -- Позиции лотосов (примерные координаты для стандартной карты)
  local lotusPositions = {
    Vector(-1800, 1200, 128),  -- Верхняя река
    Vector(1800, -1200, 128),  -- Нижняя река
  }
  
  for _, position in ipairs(lotusPositions) do
    local randomItem = lotusItems[RandomInt(1, #lotusItems)]
    local item = CreateItem(randomItem, nil, nil)
    if item then
      CreateItemOnPositionSync(position, item)
      Util.Log("DEBUG", "Spawned %s at lotus position", randomItem)
    end
  end
end

-- Настройка тайминга игры
function AllPick.SetupTimings()
  -- Время до начала игры
  Util.SafeCall(GameRules.SetPreGameTime, GameRules, GVH.PREGAME_TIME)
  
  -- Время стратегии
  Util.SafeCall(GameRules.SetStrategyTime, GameRules, GVH.STRATEGY_TIME)
  
  -- Время показа
  Util.SafeCall(GameRules.SetShowcaseTime, GameRules, GVH.SHOWCASE_TIME)
  
  -- Отключаем паузу в начале игры
  Util.SafeCall(GameRules.SetStartingGold, GameRules, 625) -- Стандартное стартовое золото
  
  Util.Log("DEBUG", "Timings setup: PreGame=%ds, Strategy=%ds, Showcase=%ds", 
           GVH.PREGAME_TIME, GVH.STRATEGY_TIME, GVH.SHOWCASE_TIME)
end

-- Дополнительные настройки для баланса 1v23
function AllPick.SetupBalance()
  -- Можем дать бонусы соло игроку для баланса
  Timers:CreateTimer(1.0, function()
    AllPick.ApplySoloPlayerBonuses()
    return 30.0 -- Проверяем каждые 30 секунд
  end)
end

-- Применение бонусов для соло игрока
function AllPick.ApplySoloPlayerBonuses()
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if Util.IsValidPlayerID(playerID) and Util.GetPlayerTeam(playerID) == GVH.TEAM_SOLO then
      local hero = Util.GetPlayerHero(playerID)
      if hero and hero:IsAlive() then
        -- Можем добавить бонусы: дополнительное золото, опыт, регенерацию и т.д.
        -- Пока оставляем пустым, можно настроить по необходимости
      end
    end
  end
end

-- Создание кастомных спавнеров рун если их нет на карте
function AllPick.CreateCustomRuneSpawners()
  -- Позиции стандартных спавнеров рун
  local runeSpawners = {
    {
      position = Vector(-2273, 1800, 256),
      type = "power"
    },
    {
      position = Vector(2273, -1800, 256), 
      type = "power"
    }
  }
  
  for _, spawner in ipairs(runeSpawners) do
    -- Создаем невидимую сущность-спавнер
    local spawnerEntity = CreateUnitByName("npc_dota_base", spawner.position, false, nil, nil, DOTA_TEAM_NEUTRALS)
    if spawnerEntity then
      spawnerEntity:AddNewModifier(spawnerEntity, nil, "modifier_invisible", {})
      spawnerEntity:SetAbsOrigin(spawner.position)
      
      -- Запускаем таймер спавна рун
      Timers:CreateTimer(function()
        AllPick.SpawnRuneAtPosition(spawner.position, spawner.type)
        return spawner.type == "power" and GVH.POWER_RUNE_INTERVAL or GVH.WATER_RUNE_INTERVAL
      end)
    end
  end
  
  Util.Log("DEBUG", "Custom rune spawners created")
end

-- Спавн руны в указанной позиции
function AllPick.SpawnRuneAtPosition(position, runeType)
  if runeType == "power" then
    local powerRunes = {
      DOTA_RUNE_DOUBLEDAMAGE,
      DOTA_RUNE_HASTE, 
      DOTA_RUNE_ILLUSION,
      DOTA_RUNE_INVISIBILITY,
      DOTA_RUNE_REGENERATION,
      DOTA_RUNE_ARCANE
    }
    local randomRune = powerRunes[RandomInt(1, #powerRunes)]
    CreateRune(position, randomRune)
  else
    CreateRune(position, DOTA_RUNE_BOUNTY)
  end
end

return AllPick