-- GVH Configuration
-- Golovach vs Haters - режим 1v23 для Dota 2 Custom Game

GVH = {
  -- Команды (используем числовые константы для надежности)
  TEAM_SOLO = 2,      -- DOTA_TEAM_GOODGUYS (Radiant)
  TEAM_HORDE = 3,     -- DOTA_TEAM_BADGUYS (Dire)
  
  -- Лимиты слотов
  SOLO_SLOTS = 1,
  HORDE_SLOTS = 23,
  MAX_SPECTATORS = 40,                -- лимит наблюдателей (40 слотов)
  
  -- Настройки балансировки
  AUTOFILL_BOTS = false,              -- при недоборе в 23
  
  -- All Pick настройки
  ENABLE_ALL_PICK = true,
  
  -- Экономика
  GOLD_PER_MIN = 120,                 -- базовое GPM
  XP_MULT = 1.0,
  
  -- Руны
  POWER_RUNE_INTERVAL = 120,          -- секунды
  WATER_RUNE_INTERVAL = 120,          -- секунды
  
  -- Лотосы
  ENABLE_LOTUS = true,
  
  -- Тайминги All Pick
  PREGAME_TIME = 15,                  -- секунды
  STRATEGY_TIME = 75,                 -- секунды
  SHOWCASE_TIME = 0,                  -- секунды
  
  -- Возврат из наблюдателей
  ALLOW_SPECTATOR_RETURN = true,      -- разрешить возврат из наблюдателей
  RETURN_WINDOW_SECONDS = 60,         -- окно возврата после смерти (секунды)
  
  -- Отладка
  DEBUG_MODE = true,                  -- включить отладочные сообщения
  LOG_PREFIX = "[GVH]"                -- префикс для логов
}

-- Константы команд для удобства (числовые значения)
GVH.TEAMS = {
  SPECTATOR = 1,  -- DOTA_TEAM_SPECTATOR
  SOLO = 2,       -- DOTA_TEAM_GOODGUYS
  HORDE = 3,      -- DOTA_TEAM_BADGUYS
  NOTEAM = 5      -- DOTA_TEAM_NOTEAM
}

return GVH