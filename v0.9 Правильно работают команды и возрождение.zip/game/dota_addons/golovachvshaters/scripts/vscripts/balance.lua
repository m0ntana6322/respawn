-- Balance module for GVH mod
-- Автозаполнение ботами, защита от переполнения команд

Balance = {}

-- Инициализация системы балансировки
function Balance.Init()
  Util.Log("INFO", "Initializing balance system...")
  
  -- Запускаем периодическую проверку баланса
  Timers:CreateTimer(5.0, function()
    Balance.CheckBalance()
    return 10.0 -- Проверяем каждые 10 секунд
  end)
  
  Util.Log("INFO", "Balance system initialized")
end

-- Основная проверка баланса команд
function Balance.CheckBalance()
  local gameState = GameRules:State_Get()
  
  -- Проверяем баланс только в определенных состояниях игры
  if gameState < DOTA_GAMERULES_STATE_HERO_SELECTION or gameState > DOTA_GAMERULES_STATE_PRE_GAME then
    return
  end
  
  local stats = Teams.GetTeamStats()
  
  -- Проверяем переполнение команд
  Balance.HandleTeamOverflow(stats)
  
  -- Проверяем недобор в командах
  Balance.HandleTeamUnderfill(stats)
  
  -- Проверяем игроков в NOTEAM
  Balance.HandleUnassignedPlayers()
end

-- Обработка переполнения команд
function Balance.HandleTeamOverflow(stats)
  -- Проверяем переполнение Solo команды
  if stats.solo.current > stats.solo.max then
    local excess = stats.solo.current - stats.solo.max
    Util.Log("WARN", "Solo team overfilled by %d players", excess)
    Balance.MoveExcessPlayers(GVH.TEAM_SOLO, excess)
  end
  
  -- Проверяем переполнение Horde команды
  if stats.horde.current > stats.horde.max then
    local excess = stats.horde.current - stats.horde.max
    Util.Log("WARN", "Horde team overfilled by %d players", excess)
    Balance.MoveExcessPlayers(GVH.TEAM_HORDE, excess)
  end
end

-- Перемещение лишних игроков из команды
function Balance.MoveExcessPlayers(teamID, excessCount)
  local teamPlayers = Balance.GetTeamPlayers(teamID)
  
  -- Сортируем по времени подключения (последние подключившиеся идут первыми)
  table.sort(teamPlayers, function(a, b)
    return PlayerResource:GetConnectionState(a) > PlayerResource:GetConnectionState(b)
  end)
  
  -- Перемещаем лишних игроков в наблюдатели
  for i = 1, math.min(excessCount, #teamPlayers) do
    local playerID = teamPlayers[i]
    Util.Log("INFO", "Moving excess player %d from team %d to spectators", playerID, teamID)
    Teams.MoveToSpectators(playerID, "balance_overflow")
  end
end

-- Обработка недобора в командах
function Balance.HandleTeamUnderfill(stats)
  if not GVH.AUTOFILL_BOTS then
    return
  end
  
  -- Проверяем недобор в Horde команде
  local hordeShortage = stats.horde.max - stats.horde.current
  if hordeShortage > 0 then
    Util.Log("DEBUG", "Horde team needs %d more players", hordeShortage)
    Balance.AddBotsToTeam(GVH.TEAM_HORDE, hordeShortage)
  end
  
  -- Solo команду ботами не заполняем - это должен быть живой игрок
end

-- Добавление ботов в команду
function Balance.AddBotsToTeam(teamID, count)
  local gameState = GameRules:State_Get()
  
  -- Добавляем ботов только до начала игры
  if gameState > DOTA_GAMERULES_STATE_PRE_GAME then
    return
  end
  
  for i = 1, count do
    local botPlayerID = Balance.CreateBot(teamID)
    if botPlayerID then
      Util.Log("INFO", "Added bot %d to team %d", botPlayerID, teamID)
    else
      Util.Log("ERROR", "Failed to create bot for team %d", teamID)
      break
    end
  end
end

-- Создание бота
function Balance.CreateBot(teamID)
  -- Список героев для ботов
  local botHeroes = {
    "npc_dota_hero_pudge",
    "npc_dota_hero_axe", 
    "npc_dota_hero_dragon_knight",
    "npc_dota_hero_sven",
    "npc_dota_hero_omniknight",
    "npc_dota_hero_wraith_king",
    "npc_dota_hero_centaur",
    "npc_dota_hero_tidehunter",
    "npc_dota_hero_bristleback",
    "npc_dota_hero_underlord"
  }
  
  -- Находим свободный слот для бота
  local botPlayerID = nil
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if not PlayerResource:IsValidPlayerID(playerID) then
      botPlayerID = playerID
      break
    end
  end
  
  if not botPlayerID then
    Util.Log("ERROR", "No free player slots for bot")
    return nil
  end
  
  -- Создаем бота
  local randomHero = botHeroes[RandomInt(1, #botHeroes)]
  local bot = Tutorial:AddBot(randomHero, "", "", false)
  
  if bot then
    -- Назначаем бота в команду
    Util.AssignPlayerToTeam(botPlayerID, teamID)
    return botPlayerID
  end
  
  return nil
end

-- Обработка неназначенных игроков
function Balance.HandleUnassignedPlayers()
  local unassignedPlayers = {}
  
  -- Находим всех игроков в NOTEAM
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if Util.IsValidPlayerID(playerID) and Util.GetPlayerTeam(playerID) == GVH.TEAMS.NOTEAM then
      table.insert(unassignedPlayers, playerID)
    end
  end
  
  if #unassignedPlayers > 0 then
    Util.Log("INFO", "Found %d unassigned players, assigning...", #unassignedPlayers)
    
    for _, playerID in ipairs(unassignedPlayers) do
      Teams.SafeAssign(playerID)
    end
  end
end

-- Получение списка игроков команды
function Balance.GetTeamPlayers(teamID)
  local players = {}
  
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if Util.IsValidPlayerID(playerID) and Util.GetPlayerTeam(playerID) == teamID then
      table.insert(players, playerID)
    end
  end
  
  return players
end

-- Проверка готовности к началу игры
function Balance.CheckGameReadiness()
  local stats = Teams.GetTeamStats()
  local issues = {}
  
  -- Проверяем наличие игроков в NOTEAM
  local unassignedCount = 0
  for playerID = 0, DOTA_MAX_PLAYERS - 1 do
    if Util.IsValidPlayerID(playerID) and Util.GetPlayerTeam(playerID) == GVH.TEAMS.NOTEAM then
      unassignedCount = unassignedCount + 1
    end
  end
  
  if unassignedCount > 0 then
    table.insert(issues, string.format("%d players in NOTEAM", unassignedCount))
  end
  
  -- Проверяем минимальные требования
  if stats.solo.current == 0 then
    table.insert(issues, "No players in Solo team")
  end
  
  if stats.horde.current == 0 then
    table.insert(issues, "No players in Horde team")
  end
  
  -- Проверяем переполнение
  if stats.solo.current > stats.solo.max then
    table.insert(issues, string.format("Solo team overfilled (%d/%d)", stats.solo.current, stats.solo.max))
  end
  
  if stats.horde.current > stats.horde.max then
    table.insert(issues, string.format("Horde team overfilled (%d/%d)", stats.horde.current, stats.horde.max))
  end
  
  return #issues == 0, issues
end

-- Принудительная балансировка перед началом игры
function Balance.ForceBalance()
  Util.Log("INFO", "Forcing balance before game start...")
  
  -- Исправляем всех неназначенных игроков
  Balance.HandleUnassignedPlayers()
  
  -- Исправляем переполнения
  local stats = Teams.GetTeamStats()
  Balance.HandleTeamOverflow(stats)
  
  -- Добавляем ботов если нужно
  if GVH.AUTOFILL_BOTS then
    Balance.HandleTeamUnderfill(Teams.GetTeamStats())
  end
  
  -- Проверяем готовность
  local ready, issues = Balance.CheckGameReadiness()
  
  if ready then
    Util.Log("INFO", "Teams balanced successfully")
  else
    Util.Log("WARN", "Balance issues remain: %s", table.concat(issues, ", "))
  end
  
  return ready
end

-- Получение статистики балансировки
function Balance.GetBalanceStats()
  local stats = Teams.GetTeamStats()
  local ready, issues = Balance.CheckGameReadiness()
  
  return {
    teams = stats,
    ready = ready,
    issues = issues,
    autofill_enabled = GVH.AUTOFILL_BOTS
  }
end

-- Обработка события начала игры
function Balance.OnGameStart()
  Util.Log("INFO", "Game starting - final balance check...")
  
  local ready = Balance.ForceBalance()
  
  if not ready then
    Util.Log("ERROR", "Game started with balance issues!")
  end
  
  -- Выводим финальную статистику
  local stats = Teams.GetTeamStats()
  Util.Log("INFO", "Final team composition - Solo: %d/%d, Horde: %d/%d, Spectators: %d/%d",
           stats.solo.current, stats.solo.max,
           stats.horde.current, stats.horde.max,
           stats.spectators.current, stats.spectators.max)
end

return Balance